package com.developer.ibra.bartertrader254;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.provider.ContactsContract;
import android.support.annotation.NonNull;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ServerValue;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.theartofdev.edmodo.cropper.CropImage;
import com.theartofdev.edmodo.cropper.CropImageView;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import id.zelory.compressor.Compressor;

public class PostData extends AppCompatActivity {

    private Toolbar postbar;
    private TextInputLayout firsthint;


    private ImageView first_item;



    private Uri first_image=null;

    private Button next;
    private ProgressDialog progressDialog;

    private StorageReference mStorage;
    private DatabaseReference databaseReference;
    private Bitmap compressedImageFile;
    private String thumblink;


    private String location="";
    private String uid="";
    private String user_thumb;


    private FirebaseUser firebaseUser;
    private String name="";








    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post_data);


        postbar=(Toolbar)findViewById(R.id.post_data_bar4);
        first_item=(ImageView)findViewById(R.id.first_image_view);
        progressDialog=new ProgressDialog(this);




        databaseReference= FirebaseDatabase.getInstance().getReference().child("posts");
        mStorage= FirebaseStorage.getInstance().getReference();

        progressDialog.setMessage("Processing");
        progressDialog.setCancelable(false);

        next=(Button)findViewById(R.id.data_next_step);

        String title=getIntent().getStringExtra("description");


        setSupportActionBar(postbar);
        getSupportActionBar().setTitle(title);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        firsthint=(TextInputLayout)findViewById(R.id.hint_post_one);

        firebaseUser= FirebaseAuth.getInstance().getCurrentUser();

        uid=firebaseUser.getUid();

        final DatabaseReference snapshot=FirebaseDatabase.getInstance().getReference("Users").child(uid);



        String number1=getIntent().getStringExtra("hint1");
        final String number2=getIntent().getStringExtra("hint2");




        firsthint.setHint(number1);
        final String randoma= UUID.randomUUID().toString();



        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                final String firstdesc=firsthint.getEditText().getText().toString();

                snapshot.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {


                        location=dataSnapshot.child("Location").getValue().toString();
                        user_thumb=dataSnapshot.child("Thumb_image").getValue().toString();
                        name=dataSnapshot.child("Name").getValue().toString();

                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {

                    }
                });

                if (!TextUtils.isEmpty(firstdesc)&&first_image!=null)


                {

                    progressDialog.show();


                    String time= ServerValue.TIMESTAMP.toString();

                    StorageReference filepath=mStorage.child("Post_Images").child(randoma +".jpg");

                    filepath.putFile(first_image).addOnCompleteListener(new OnCompleteListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<UploadTask.TaskSnapshot> task) {



                            String imagepath=task.getResult().getDownloadUrl().toString();
                            File actualImageFile=new File(first_image.getPath());


                            compressedImageFile = new Compressor(PostData.this).setMaxWidth(200).setMaxHeight(200).setQuality(10).
                                    compressToBitmap(actualImageFile);
                            ByteArrayOutputStream byteArrayOutputStream=new ByteArrayOutputStream();


                            compressedImageFile.compress(Bitmap.CompressFormat.JPEG,75,byteArrayOutputStream);
                            byte  [] data=byteArrayOutputStream.toByteArray();


                            Calendar cal=Calendar.getInstance();

                            SimpleDateFormat format=new SimpleDateFormat("HH:mm:ss");

                            String time=format.format(cal.getTime());
                            final String date= DateFormat.getDateInstance(DateFormat.SHORT).format(cal.getTime());



                            UploadTask uploadTask=mStorage.child("Post_Images/thumbs")
                                    .child(randoma+".jpg").putBytes(data);


                            uploadTask.addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                                @Override
                                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {

                                    final String link=taskSnapshot.getDownloadUrl().toString();


                                    DatabaseReference ibrahimdiba=databaseReference.push();
                                    String ibra = ibrahimdiba.getKey();




                                    Map uploadmap=new HashMap();

                                    uploadmap.put("Image",link);
                                    uploadmap.put("first_desc", firstdesc);
                                    uploadmap.put("Location", location);
                                    uploadmap.put("UID", uid);
                                    uploadmap.put("Thumb_image",user_thumb);
                                    uploadmap.put("Name", name);
                                    uploadmap.put("Date", date);
                                    uploadmap.put("Post_id", ibra);




                                    ibrahimdiba.setValue(uploadmap);





                                    progressDialog.dismiss();

                                    Intent intent=new Intent(PostData.this, PostData2.class);


                                    intent.putExtra("hint22", number2);
                                    intent.putExtra("data", ibra);

                                    startActivity(intent);






                                }
                            }).addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {

                                }
                            });






                        }
                    });



                }

                else
                {

                    Toast.makeText(PostData.this, "Please provide all needed information", Toast.LENGTH_LONG).show();
                }





                /*Intent intent=new Intent(PostData.this, PostData2.class);


                intent.putExtra("hint22", number2);

                startActivity(intent); */
            }
        });



        first_item.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CropImage.activity()
                        .setGuidelines(CropImageView.Guidelines.ON)
                        .setMinCropResultSize(512, 512)
                        .setAspectRatio(2, 2)
                        .start(PostData.this);
            }
        });





    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);


        if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE) {
            CropImage.ActivityResult result = CropImage.getActivityResult(data);
            if (resultCode == RESULT_OK) {

                first_image = result.getUri();
                first_item.setImageURI(first_image);

            } else if (resultCode == CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE) {

                Exception error = result.getError();

            }
        }




    }



}

