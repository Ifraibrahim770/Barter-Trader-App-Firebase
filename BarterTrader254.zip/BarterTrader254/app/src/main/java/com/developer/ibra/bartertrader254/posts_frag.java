package com.developer.ibra.bartertrader254;


import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.developer.ibra.bartertrader254.Interface.ItemClickListener;
import com.developer.ibra.bartertrader254.ViewHolder.Post_ViewHolder;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Callback;
import com.squareup.picasso.NetworkPolicy;
import com.squareup.picasso.Picasso;


/**
 * A simple {@link Fragment} subclass.
 */
public class posts_frag extends Fragment {

    private RecyclerView mview;
    private DatabaseReference databaseReference;
    private LinearLayoutManager layoutManager;

    private Picasso mPicasso;



    public posts_frag() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment


        View view = inflater.inflate(R.layout.fragment_posts_frag, container, false);

        FirebaseUser firebaseUser= FirebaseAuth.getInstance().getCurrentUser();




        mview = (RecyclerView)view.findViewById(R.id.user_posts);


        if (firebaseUser!=null)
        {

            databaseReference = FirebaseDatabase.getInstance().getReference("User_posts").child(firebaseUser.getUid());
            databaseReference.keepSynced(true);

        }







        mPicasso=Picasso.with(getActivity());
        mPicasso.setIndicatorsEnabled(false);


        layoutManager = new LinearLayoutManager(getActivity());
        layoutManager.setReverseLayout(true);
        layoutManager.setStackFromEnd(true);
        mview.setLayoutManager(layoutManager);


        if  (firebaseUser!=null)

        {

            loadmenu();

        }




        return view;
    }

    private void loadmenu() {FirebaseRecyclerAdapter<Constructor, Post_ViewHolder> adapter = new FirebaseRecyclerAdapter<Constructor, Post_ViewHolder>(Constructor.class, R.layout.post_item, Post_ViewHolder.class, databaseReference) {
        @Override
        protected void populateViewHolder(final Post_ViewHolder viewHolder, final Constructor model, int position) {


            if (!model.getThumb_image().equals("null") && !model.getImage().equals("null") && !model.getImage2().equals("null")) {



                mPicasso.load(model.getImage()).networkPolicy(NetworkPolicy.OFFLINE).placeholder(R.drawable.default_circle).into(viewHolder.first_image, new Callback() {
                    @Override
                    public void onSuccess() {

                    }

                    @Override
                    public void onError() {

                        mPicasso.load(model.getImage()).placeholder(R.drawable.default_circle).into(viewHolder.first_image);

                    }
                });

                mPicasso.load(model.getImage2()).networkPolicy(NetworkPolicy.OFFLINE).placeholder(R.drawable.default_circle).into(viewHolder.second_image, new Callback() {
                    @Override
                    public void onSuccess() {

                    }

                    @Override
                    public void onError() {

                        mPicasso.load(model.getImage2()).placeholder(R.drawable.default_circle).into(viewHolder.second_image);

                    }
                });


            }


            DatabaseReference ibrahimdiba=FirebaseDatabase.getInstance().getReference("Users").child(model.getUID());


            ibrahimdiba.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {



                    String name=dataSnapshot.child("Name").getValue().toString();

                    final String thumbimage=dataSnapshot.child("Thumb_image").getValue().toString();



                    mPicasso.load(thumbimage).networkPolicy(NetworkPolicy.OFFLINE).placeholder(R.drawable.default_circle).into(viewHolder.user_thumbnail, new Callback() {
                        @Override
                        public void onSuccess() {

                        }

                        @Override
                        public void onError() {

                            mPicasso.load(thumbimage).placeholder(R.drawable.default_circle).into(viewHolder.user_thumbnail);

                        }
                    });







                    viewHolder.user_name.setText(name);
                    viewHolder.date1.setText(model.getDate());
                    viewHolder.user_location.setText(model.getLocation());

                    viewHolder.first_description.setText(model.getFirst_desc());
                    viewHolder.second_description.setText(model.getDesc2());


                }

                @Override
                public void onCancelled(DatabaseError databaseError) {

                }
            });



            String ibrahim=model.getPost_id();


            DatabaseReference databaseReference=FirebaseDatabase.getInstance().getReference("Comments").child(ibrahim);
            databaseReference.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {

                    int arodi= (int) dataSnapshot.getChildrenCount();
                    String pro2=String.valueOf(arodi);


                    viewHolder.comment_count.setText(pro2);


                }

                @Override
                public void onCancelled(DatabaseError databaseError) {

                }
            });


            viewHolder.user_name.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {



                    String userid=model.getUID();

                    Intent intent=new Intent(getActivity(), Profile.class);

                    intent.putExtra("UID", userid);
                    startActivity(intent);
                }
            });

            viewHolder.user_thumbnail.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    String userid=model.getUID();

                    Intent intent=new Intent(getActivity(), Profile.class);

                    intent.putExtra("UID", userid);
                    startActivity(intent);

                }
            });

            viewHolder.message.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    Intent intent=new Intent(getActivity(), Chat.class);
                    startActivity(intent);

                }
            });


            viewHolder.mesage.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    Intent intent=new Intent(getActivity(), Chat.class);


                    startActivity(intent);

                }
            });




           // viewHolder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
               // @Override
                //public boolean onLongClick(View view) {


                //}
           // });






            final Constructor clickItem = model;
            viewHolder.setItemClickListener(new ItemClickListener() {
                @Override
                public void onClick(View view, int position, boolean isLongClick) {


                    String user_value = clickItem.getPost_id();


                    if (!TextUtils.isEmpty(clickItem.getPost_id())) {
                        final Intent intent = new Intent(getActivity(), Comments.class);
                        intent.putExtra("UID", user_value);


                        startActivity(intent);
                    }



                    viewHolder.mesage.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {

                            Intent intent=new Intent(getActivity(), Chat.class);

                            String string=clickItem.getUID();

                            intent.putExtra("Message_uid", string);


                            startActivity(intent);

                        }
                    });






                    viewHolder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
                        @Override
                        public boolean onLongClick(View view) {


                            CharSequence options[]=new CharSequence[]{ "View Post Details"};

                            final AlertDialog.Builder builder=new AlertDialog.Builder(getActivity());

                            builder.setTitle("Select Options");
                            builder.setItems(options, new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i)


                                {




                                    if (i==0)

                                    {

                                        Intent intent=new Intent(getContext(),Comments.class);

                                        String user_value=model.getPost_id();
                                        intent.putExtra("UID", user_value);
                                        startActivity(intent);

                                    }

                                }
                            });

                            builder.show();


                            // Toast.makeText(getActivity(), "Umelong Click Msee", Toast.LENGTH_LONG).show();




                            return true;
                        }
                    });


                }

                final  Constructor clickItem=model;
            });

        }


    };

        mview.setAdapter(adapter);







    }

}
