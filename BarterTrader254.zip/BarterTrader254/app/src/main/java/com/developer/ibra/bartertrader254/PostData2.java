package com.developer.ibra.bartertrader254;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.theartofdev.edmodo.cropper.CropImage;
import com.theartofdev.edmodo.cropper.CropImageView;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

import id.zelory.compressor.Compressor;

public class PostData2 extends AppCompatActivity {


    private TextInputLayout second_desc;
    private android.support.v7.widget.Toolbar toolbar;

    private ImageView imageView;
    private Uri first_image=null;

    private StorageReference mStorage;
    private DatabaseReference databaseReference;


    private Button finish;

    private ProgressDialog progressDialog;


    private Bitmap compressedImageFile;
    private String downloadstring;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post_data2);


        finish=(Button)findViewById(R.id.finish_button);


        toolbar=(android.support.v7.widget.Toolbar)findViewById(R.id.postbar2);

        imageView=(ImageView)findViewById(R.id.advanced_image);


        second_desc=(TextInputLayout)findViewById(R.id.hint_post_two);

        progressDialog=new ProgressDialog(this);

        progressDialog.setMessage("Finalizing...");


        String dbref=getIntent().getStringExtra("data");



        mStorage=FirebaseStorage.getInstance().getReference();
        databaseReference= FirebaseDatabase.getInstance().getReference().child("posts").child(dbref);




        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Final Step");

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);



        String hint=getIntent().getStringExtra("hint22");

        second_desc.setHint(hint);


        finish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                final String seconddesc=second_desc.getEditText().getText().toString();


                final String randoma= UUID.randomUUID().toString();


                if(first_image!=null && !TextUtils.isEmpty(seconddesc))

                {
                    progressDialog.show();

                    StorageReference filepath=mStorage.child("Post_Images").child(randoma+".jpg");
                    filepath.putFile(first_image).addOnCompleteListener(new OnCompleteListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<UploadTask.TaskSnapshot> task) {


                            if (task.isSuccessful())

                            {

                                String imagepath=task.getResult().getDownloadUrl().toString();

                                File actualImageFile=new File(first_image.getPath());


                                compressedImageFile = new Compressor(PostData2.this).compressToBitmap(actualImageFile);
                                ByteArrayOutputStream byteArrayOutputStream=new ByteArrayOutputStream();


                                compressedImageFile.compress(Bitmap.CompressFormat.JPEG,75,byteArrayOutputStream);
                                byte  [] data=byteArrayOutputStream.toByteArray();


                                UploadTask uploadTask=mStorage.child("Post_Images/thumbs")
                                        .child(randoma+".jpg").putBytes(data);


                                uploadTask.addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                                    @Override
                                    public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {


                                        final String downloadstring2=taskSnapshot.getDownloadUrl().toString();

                                        Map ibra=new HashMap();

                                        ibra.put("Image2", downloadstring2);
                                        ibra.put("Desc2", seconddesc);

                                        databaseReference.updateChildren(ibra);




                                        progressDialog.dismiss();


                                        Intent intent=new Intent(PostData2.this, MainActivity.class);

                                        startActivity(intent);

                                        Toast.makeText(PostData2.this, "Success!, Your Post is being reviewed", Toast.LENGTH_LONG).show();




                                    }
                                }).addOnFailureListener(new OnFailureListener() {
                                    @Override
                                    public void onFailure(@NonNull Exception e) {

                                    }
                                });




                            }


                            else
                            {

                                progressDialog.dismiss();

                                Toast.makeText(PostData2.this, "Error: "+task.getException().getMessage(),Toast.LENGTH_LONG).show();
                            }

                        }
                    });

                }


                else

                {
                    Toast.makeText(PostData2.this, "Please fill in all empty fields", Toast.LENGTH_LONG).show();
                }



            }
        });


        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                CropImage.activity()
                        .setGuidelines(CropImageView.Guidelines.ON)
                        .setMinCropResultSize(512, 512)
                        .setAspectRatio(2, 2)
                        .start(PostData2.this);
            }
        });
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);


        if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE) {
            CropImage.ActivityResult result = CropImage.getActivityResult(data);
            if (resultCode == RESULT_OK) {

                first_image = result.getUri();
                imageView.setImageURI(first_image);

            } else if (resultCode == CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE) {

                Exception error = result.getError();

            }
        }




    }


    public static String random() {
        Random generator = new Random();
        StringBuilder randomStringBuilder = new StringBuilder();
        int randomLength = generator.nextInt(10);
        char tempChar;
        for (int i = 0; i < randomLength; i++){
            tempChar = (char) (generator.nextInt(96) + 32);
            randomStringBuilder.append(tempChar);
        }
        return randomStringBuilder.toString();
    }



}
