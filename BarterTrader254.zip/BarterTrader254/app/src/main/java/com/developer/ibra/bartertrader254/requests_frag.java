package com.developer.ibra.bartertrader254;


import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.algolia.instantsearch.ui.views.SearchBox;
import com.developer.ibra.bartertrader254.Interface.ItemClickListener;
import com.developer.ibra.bartertrader254.ViewHolder.Post_ViewHolder;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Callback;
import com.squareup.picasso.NetworkPolicy;
import com.squareup.picasso.Picasso;

import java.util.HashMap;
import java.util.Map;


/**
 * A simple {@link Fragment} subclass.
 */
public class requests_frag extends Fragment {


    private RecyclerView recyclerView;
    private DatabaseReference databaseReference;
    private LinearLayoutManager layoutManager;
    private Picasso mPicasso;


    private String name;

    private SearchBox searchBox;



    public requests_frag() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_requests_frag, container, false);


        recyclerView = view.findViewById(R.id.requests_posts_recycler);


        mPicasso=Picasso.with(getActivity());
        mPicasso.setIndicatorsEnabled(false);

        recyclerView.setHasFixedSize(true);

        layoutManager = new LinearLayoutManager(getActivity());
        layoutManager.setReverseLayout(true);
        layoutManager.setStackFromEnd(true);

        recyclerView.setLayoutManager(layoutManager);


        FirebaseUser firebaseUser=FirebaseAuth.getInstance().getCurrentUser();

        databaseReference = FirebaseDatabase.getInstance().getReference("advanced_trade_requests").child(firebaseUser.getUid());
        databaseReference.keepSynced(true);



        if (firebaseUser!=null)

        {
            loaddata();
        }







        return view;
    }

    private void loaddata() {



        FirebaseRecyclerAdapter<Constructor, Post_ViewHolder> adapter = new FirebaseRecyclerAdapter<Constructor, Post_ViewHolder>(Constructor.class,
                R.layout.advanced_request_item, Post_ViewHolder.class, databaseReference) {
            @Override
            protected void populateViewHolder(final Post_ViewHolder viewHolder, final Constructor model, int position) {


                DatabaseReference awino=FirebaseDatabase.getInstance().getReference("Users").child(model.getUID());



                awino.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {



                        final String image=dataSnapshot.child("Thumb_image").getValue().toString();

                        mPicasso.load(image).networkPolicy(NetworkPolicy.OFFLINE).placeholder(R.drawable.default_circle).into(viewHolder.user_thumbnail2, new Callback() {
                            @Override
                            public void onSuccess() {

                            }

                            @Override
                            public void onError() {

                                mPicasso.load(image).placeholder(R.drawable.default_circle).into(viewHolder.user_thumbnail2);

                            }
                        });

                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {

                    }
                });




                    mPicasso.load(model.getImage()).networkPolicy(NetworkPolicy.OFFLINE).placeholder(R.drawable.default_circle).into(viewHolder.first_image2, new Callback() {
                        @Override
                        public void onSuccess() {

                        }

                        @Override
                        public void onError() {

                            mPicasso.load(model.getImage()).placeholder(R.drawable.default_circle).into(viewHolder.first_image2);

                        }
                    });

                    mPicasso.load(model.getImage2()).networkPolicy(NetworkPolicy.OFFLINE).placeholder(R.drawable.default_circle).into(viewHolder.second_image2, new Callback() {
                        @Override
                        public void onSuccess() {

                        }

                        @Override
                        public void onError() {

                            mPicasso.load(model.getImage2()).placeholder(R.drawable.default_circle).into(viewHolder.second_image2);

                        }
                    });


                DatabaseReference databaseReference12=FirebaseDatabase.getInstance().getReference("Users").child(model.getUID());


                databaseReference12.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {


                        name=dataSnapshot.child("Name").getValue().toString();


                        viewHolder.user_name2.setText(name);
                        viewHolder.date12.setText(model.getDate());
                        viewHolder.user_location2.setText(model.getLocation());

                        viewHolder.first_description2.setText(model.getFirst_desc());
                        viewHolder.second_description2.setText(model.getDesc2());


                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {

                    }
                });
                String ibrahim=model.getPost_id();






                viewHolder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
                    @Override
                    public boolean onLongClick(View view) {


                        CharSequence options[]=new CharSequence[]{ "View Post Details", "Report Post", "Message Seller"};

                        final AlertDialog.Builder builder=new AlertDialog.Builder(getActivity());

                        builder.setTitle("Select Option");
                        builder.setItems(options, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i)


                            {



                                if (i==0)

                                {



                                }





                            }
                        });

                        builder.show();


                        // Toast.makeText(getActivity(), "Umelong Click Msee", Toast.LENGTH_LONG).show();




                        return true;
                    }
                });




                final Constructor clickItem = model;
                viewHolder.setItemClickListener(new ItemClickListener() {
                    @Override
                    public void onClick(View view, int position, boolean isLongClick) {



                        final String post_user=model.getSecond_user();
                        final String main_user=model.getUID();


                        final String post_user_post=model.getPost1();
                        final String main_user_post=model.getPost2();




                        CharSequence options[]=new CharSequence[]{ "Accept Trade Deal", "Decline", "Message Seller"};

                        final AlertDialog.Builder builder=new AlertDialog.Builder(getActivity());

                        builder.setTitle("Select Option");
                        builder.setItems(options, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i)


                            {


                                if (i==0)
                                {







                                    final DatabaseReference ibrahim=FirebaseDatabase.getInstance().getReference("User_approved_advanced_posts")
                                            .child(post_user).child(post_user_post);



                                    ibrahim.addValueEventListener(new ValueEventListener() {
                                        @Override
                                        public void onDataChange(DataSnapshot dataSnapshot) {




                                            String acc=dataSnapshot.child("Accessories").getValue().toString();
                                            String condition_string=dataSnapshot.child("Condition").getValue().toString();
                                            String date_string=dataSnapshot.child("Date").getValue().toString();
                                            String desc_string=dataSnapshot.child("Desc2").getValue().toString();
                                            String func_string=dataSnapshot.child("Functionality").getValue().toString();
                                            final String image=dataSnapshot.child("Image2").getValue().toString();
                                            String locationn=dataSnapshot.child("Location").getValue().toString();
                                            String  reciept_string=dataSnapshot.child("Reciept").getValue().toString();



                                            final Map ibra=new HashMap();



                                            //ibra.put("UID", uid);
                                            //ibra.put("Post_id",post_id);
                                            ibra.put("Location", locationn);
                                            ibra.put("Date", date_string);
                                            ibra.put("Image2", image);

                                            ibra.put("Desc2", desc_string);


                                            ibra.put("Accessories", acc);
                                            ibra.put("Reciept",reciept_string);
                                            ibra.put("Condition", condition_string);
                                            ibra.put("Functionality", func_string);
                                            ibra.put("UID",post_user);




                                            DatabaseReference diba=FirebaseDatabase.getInstance().getReference("User_approved_advanced_posts")
                                                    .child(main_user).child(post_user_post);


                                            diba.setValue(ibra).addOnCompleteListener(new OnCompleteListener<Void>() {
                                                @Override
                                                public void onComplete(@NonNull Task<Void> task) {


                                                    if (task.isSuccessful())


                                                    {


                                                        ibrahim.removeValue();
                                                    }

                                                }
                                            });



                                        }

                                        @Override
                                        public void onCancelled(DatabaseError databaseError) {

                                        }
                                    });





                                    final DatabaseReference judas=FirebaseDatabase.getInstance().getReference("User_approved_advanced_posts").child(main_user)
                                            .child(main_user_post);


                                    judas.addValueEventListener(new ValueEventListener() {
                                        @Override
                                        public void onDataChange(DataSnapshot dataSnapshot) {


                                            String acc=dataSnapshot.child("Accessories").getValue().toString();
                                            String condition_string=dataSnapshot.child("Condition").getValue().toString();
                                            String date_string=dataSnapshot.child("Date").getValue().toString();
                                            String desc_string=dataSnapshot.child("Desc2").getValue().toString();
                                            String func_string=dataSnapshot.child("Functionality").getValue().toString();
                                            final String image=dataSnapshot.child("Image2").getValue().toString();
                                            String locationn=dataSnapshot.child("Location").getValue().toString();
                                            String  reciept_string=dataSnapshot.child("Reciept").getValue().toString();



                                            final Map ibrah=new HashMap();

                                            //ibra.put("UID", uid);
                                            //ibra.put("Post_id",post_id);
                                            ibrah.put("Location", locationn);
                                            ibrah.put("Date", date_string);
                                            ibrah.put("Image2", image);

                                            ibrah.put("Desc2", desc_string);


                                            ibrah.put("Accessories", acc);
                                            ibrah.put("Reciept",reciept_string);
                                            ibrah.put("Condition", condition_string);
                                            ibrah.put("Functionality", func_string);

                                            ibrah.put("UID", main_user);



                                            DatabaseReference diba=FirebaseDatabase.getInstance().getReference("User_approved_advanced_posts")
                                                    .child(post_user).child(main_user_post);



                                            diba.setValue(ibrah).addOnCompleteListener(new OnCompleteListener<Void>() {
                                                @Override
                                                public void onComplete(@NonNull Task<Void> task) {



                                                    if (task.isSuccessful())

                                                    {

                                                        judas.removeValue();
                                                    }

                                                }
                                            });





                                        }

                                        @Override
                                        public void onCancelled(DatabaseError databaseError) {

                                        }
                                    });






                                    }


                                if (i==1)


                                {


                                    Toast.makeText(getActivity(), ""+post_user, Toast.LENGTH_SHORT).show();
                                }


                                if (i==2)

                                {
                                    Toast.makeText(getActivity(), ""+main_user, Toast.LENGTH_SHORT).show();
                                }






                            }
                        });

                        builder.show();


                        // Toast.makeText(getActivity(), "Umelong Click Msee", Toast.LENGTH_LONG).show();


















                    }
                });

            }


        };

        recyclerView.setAdapter(adapter);

    }

    private void accepttradedeal() {







    }

}
