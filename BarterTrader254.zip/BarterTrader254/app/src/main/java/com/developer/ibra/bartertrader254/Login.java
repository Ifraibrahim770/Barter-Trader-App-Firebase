package com.developer.ibra.bartertrader254;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class Login extends AppCompatActivity {

    private TextView reg_text;
    private Toolbar login_toolbar;

    private EditText email;
    private EditText password;

    private FirebaseAuth mAuth;

    private Button sign_in;

    private ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);


        reg_text=(TextView)findViewById(R.id.login_text_reg);
        login_toolbar=(Toolbar)findViewById(R.id.location_bar);


        email=(EditText)findViewById(R.id.log_email);
        password=(EditText)findViewById(R.id.log_pass);


        sign_in=(Button)findViewById(R.id.btn_sign_in);

        mAuth=FirebaseAuth.getInstance();

        progressDialog=new ProgressDialog(this);

        progressDialog.setTitle("Please Wait");
        progressDialog.setCancelable(false);
        progressDialog.setMessage("Signing you in....");



        setSupportActionBar(login_toolbar);
        getSupportActionBar().setTitle("Sign In");

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        sign_in.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String email_text=email.getText().toString();

                String password_text=password.getText().toString();



                if  (!TextUtils.isEmpty(email_text)&&!TextUtils.isEmpty(password_text))

                {

                    progressDialog.show();

                    mAuth.signInWithEmailAndPassword(email_text, password_text).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {


                            if (task.isSuccessful())

                            {
                                progressDialog.dismiss();
                                Toast.makeText(Login.this, "Login Succesful", Toast.LENGTH_LONG).show();
                                Intent intent=new Intent(Login.this, MainActivity.class);

                                startActivity(intent);
                                finish();
                            }

                            else
                            {
                                progressDialog.dismiss();
                                Toast.makeText(Login.this, "Error: "+task.getException().getMessage(), Toast.LENGTH_LONG).show();
                            }

                        }
                    });

                }

                else
                {

                    Toast.makeText(Login.this, "Please Fill in the missing gaps", Toast.LENGTH_LONG).show();
                }


            }
        });


        reg_text.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(Login.this, Registration.class);
                startActivity(intent);
            }
        });
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();


        finish();
    }
}
