package com.developer.ibra.bartertrader254.ViewHolder;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

import com.developer.ibra.bartertrader254.Interface.ItemClickListener;
import com.developer.ibra.bartertrader254.R;

import de.hdodenhof.circleimageview.CircleImageView;

public class MenuViewHolder extends RecyclerView.ViewHolder  implements View.OnClickListener {

    public TextView displayname;
    public TextView  uid;
    public CircleImageView profile_pic;
    public TextView status;

    private ItemClickListener itemClickListener;


    public MenuViewHolder(View itemView) {

        super(itemView);

        displayname=(TextView)itemView.findViewById(R.id.item_name);
        uid=(TextView)itemView.findViewById(R.id.item_id);
        profile_pic=(CircleImageView)itemView.findViewById(R.id.profile_image);
        status=(TextView)itemView.findViewById(R.id.item_status);

        itemView.setOnClickListener(this);


    }

    public void setItemClickListener(ItemClickListener itemClickListener) {
        this.itemClickListener = itemClickListener;
    }

    @Override
    public void onClick(View view) {

        itemClickListener.onClick(view,getAdapterPosition(),false);

    }
}
