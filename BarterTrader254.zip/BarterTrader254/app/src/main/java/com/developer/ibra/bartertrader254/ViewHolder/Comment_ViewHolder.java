package com.developer.ibra.bartertrader254.ViewHolder;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

import com.developer.ibra.bartertrader254.Interface.ItemClickListener;
import com.developer.ibra.bartertrader254.R;

import de.hdodenhof.circleimageview.CircleImageView;

public class Comment_ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

    public TextView lily_name;
    public CircleImageView lily_thumb;
    public TextView lily_date;
    public TextView lily_time;
    public TextView lily_comment;

    private ItemClickListener itemClickListener;

    public Comment_ViewHolder(View itemView) {
        super(itemView);

        lily_time=(TextView)itemView.findViewById(R.id.ifra_time);
        lily_date=(TextView)itemView.findViewById(R.id.ifra_date);
        lily_thumb=(CircleImageView)itemView.findViewById(R.id.ifra_thumb);
        lily_name=(TextView)itemView.findViewById(R.id.ifra_name);
        lily_comment=(TextView)itemView.findViewById(R.id.ifra_comment);

        itemView.setOnClickListener(this);
    }


    public void setItemClickListener(ItemClickListener itemClickListener) {
        this.itemClickListener = itemClickListener;
    }

    @Override
    public void onClick(View view) {

        itemClickListener.onClick(view,getAdapterPosition(),false);


    }
}
