package com.developer.ibra.bartertrader254;

public class Comment_Category {


    private String Name;
    private String Image;
    private String Date;
    private String Time;
    private String Comment;
    private String UID;

    public Comment_Category() {
    }

    public Comment_Category(String name, String image, String date, String time, String comment, String UID) {
        Name = name;
        Image = image;
        Date = date;
        Time = time;
        Comment = comment;
        this.UID = UID;
    }


    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getImage() {
        return Image;
    }

    public void setImage(String image) {
        Image = image;
    }

    public String getDate() {
        return Date;
    }

    public void setDate(String date) {
        Date = date;
    }

    public String getTime() {
        return Time;
    }

    public void setTime(String time) {
        Time = time;
    }

    public String getComment() {
        return Comment;
    }

    public void setComment(String comment) {
        Comment = comment;
    }

    public String getUID() {
        return UID;
    }

    public void setUID(String UID) {
        this.UID = UID;
    }
}
