package com.developer.ibra.bartertrader254;


public class Category {


    private String Name;
    private String Thumb_image;
    private String UID;
    private String Status;


    public Category() {
    }


    public Category(String name, String thumb_image, String UID, String status) {
        Name = name;
        Thumb_image = thumb_image;
        this.UID = UID;
        Status = status;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getThumb_image() {
        return Thumb_image;
    }

    public void setThumb_image(String thumb_image) {
        Thumb_image = thumb_image;
    }

    public String getUID() {
        return UID;
    }

    public void setUID(String UID) {
        this.UID = UID;
    }

    public String getStatus() {
        return Status;
    }

    public void setStatus(String status) {
        Status = status;
    }
}
