package com.developer.ibra.bartertrader254;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Toast;

import com.algolia.instantsearch.ui.views.SearchBox;
import com.developer.ibra.bartertrader254.Interface.ItemClickListener;
import com.developer.ibra.bartertrader254.ViewHolder.Post_ViewHolder;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Callback;
import com.squareup.picasso.NetworkPolicy;
import com.squareup.picasso.Picasso;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

public class ItemSelector extends AppCompatActivity {


    private RecyclerView recyclerView;
    private DatabaseReference databaseReference;
    private LinearLayoutManager layoutManager;
    private Picasso mPicasso;


    private String name;

    private SearchBox searchBox;


    private FirebaseUser firebaseUser;

    private ProgressDialog progressDialog;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item_selector);


        recyclerView = (RecyclerView)findViewById(R.id.advanced_item_selector);

        firebaseUser= FirebaseAuth.getInstance().getCurrentUser();
        databaseReference = FirebaseDatabase.getInstance().getReference("User_approved_advanced_posts").child(firebaseUser.getUid());
        databaseReference.keepSynced(true);

        mPicasso=Picasso.with(ItemSelector.this);
        mPicasso.setIndicatorsEnabled(false);

        recyclerView.setHasFixedSize(true);

        layoutManager = new LinearLayoutManager(ItemSelector.this);
        layoutManager.setReverseLayout(true);
        layoutManager.setStackFromEnd(true);

        recyclerView.setLayoutManager(layoutManager);
        FirebaseUser firebaseUser= FirebaseAuth.getInstance().getCurrentUser();

        progressDialog=new ProgressDialog(this);

        progressDialog.setMessage("Processing Request...");
        progressDialog.setCanceledOnTouchOutside(false);

        if (firebaseUser!=null)

        {
            loaddata();
        }

    }

    private void loaddata() {

        FirebaseRecyclerAdapter<Constructor, Post_ViewHolder> adapter = new FirebaseRecyclerAdapter<Constructor, Post_ViewHolder>(Constructor.class,
                R.layout.advanced_item, Post_ViewHolder.class, databaseReference) {
            @Override
            protected void populateViewHolder(final Post_ViewHolder viewHolder, final Constructor model, int position) {


                DatabaseReference awino=FirebaseDatabase.getInstance().getReference("Users").child(model.getUID());



                awino.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {



                        final String image=dataSnapshot.child("Thumb_image").getValue().toString();

                        mPicasso.load(image).networkPolicy(NetworkPolicy.OFFLINE).placeholder(R.drawable.default_circle).into(viewHolder.lovithumb, new Callback() {
                            @Override
                            public void onSuccess() {

                            }

                            @Override
                            public void onError() {

                                mPicasso.load(image).placeholder(R.drawable.default_circle).into(viewHolder.lovithumb);

                            }
                        });

                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {

                    }
                });






                mPicasso.load(model.getImage2()).networkPolicy(NetworkPolicy.OFFLINE).placeholder(R.drawable.default_circle).into(viewHolder.loviimageview, new Callback() {
                    @Override
                    public void onSuccess() {

                    }

                    @Override
                    public void onError() {

                        mPicasso.load(model.getImage2()).placeholder(R.drawable.default_circle).into(viewHolder.loviimageview);

                    }
                });


                DatabaseReference databaseReference12=FirebaseDatabase.getInstance().getReference("Users").child(model.getUID());


                databaseReference12.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {


                        name=dataSnapshot.child("Name").getValue().toString();


                        viewHolder.loviname.setText(name);
                        viewHolder.lovidate.setText(model.getDate());
                        viewHolder.lovilocation.setText(model.getLocation());

                        //viewHolder.first_description.setText(model.getFirst_desc());
                        viewHolder.lovidescription.setText(model.getDesc2());


                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {

                    }
                });
                String ibrahim=model.getPost_id();








                /*viewHolder.message.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                        Intent intent=new Intent(getActivity(), Chat.class);
                        startActivity(intent);

                    }
                }); */


               /* viewHolder.mesage.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                        Intent intent=new Intent(getActivity(), Chat.class);
                        startActivity(intent);

                    }
                }); */



                viewHolder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
                    @Override
                    public boolean onLongClick(View view) {


                        CharSequence options[]=new CharSequence[]{ "View Post Details", "Report Post", "Message Seller"};

                        final AlertDialog.Builder builder=new AlertDialog.Builder(ItemSelector.this);

                        builder.setTitle("Select Option");
                        builder.setItems(options, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i)


                            {





                            }
                        });

                        builder.show();


                        // Toast.makeText(getActivity(), "Umelong Click Msee", Toast.LENGTH_LONG).show();




                        return true;
                    }
                });




                final Constructor clickItem = model;
                viewHolder.setItemClickListener(new ItemClickListener() {
                    @Override
                    public void onClick(View view, int position, boolean isLongClick) {


                        CharSequence options[]=new CharSequence[]{ "Confirm Item Selection", "Cancel"};

                        final AlertDialog.Builder builder=new AlertDialog.Builder(ItemSelector.this);

                        builder.setTitle("Select Option");
                        builder.setItems(options, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, final int i)


                            {

                                if (i==0)
                                {

                                    progressDialog.show();

                                    final String postvalue=getIntent().getStringExtra("advanced_post_id");

                                    final DatabaseReference
                                            databaseReference=FirebaseDatabase.getInstance().
                                            getReference("Approved_advanced_posts").child(postvalue);



                                    databaseReference.addValueEventListener(
                                            new ValueEventListener() {
                                                @Override
                                                public void onDataChange(DataSnapshot dataSnapshot) {

                                                    final String image=dataSnapshot.child("Image2").getValue().toString();
                                                    final String desc=dataSnapshot.child("Desc2").getValue().toString();




                                                    final String postvalue2=clickItem.getPost_id();


                                                    DatabaseReference databaseReference1=FirebaseDatabase.getInstance().
                                                            getReference("Approved_advanced_posts")
                                                            .child(postvalue2);



                                                    databaseReference1.addValueEventListener(new ValueEventListener() {
                                                        @Override
                                                        public void onDataChange(DataSnapshot dataSnapshot) {


                                                            final String ibraas=dataSnapshot.child("Image2").getValue().toString();
                                                            final String desc1=dataSnapshot.child("Desc2").getValue().toString();


                                                            FirebaseUser firebaseUser=FirebaseAuth.getInstance().getCurrentUser();
                                                            final String user_string=firebaseUser.getUid();


                                                            DatabaseReference databaseReference21=
                                                                    FirebaseDatabase.getInstance().getReference("Users").child(user_string);


                                                            databaseReference21.addValueEventListener(new ValueEventListener() {
                                                                @Override
                                                                public void onDataChange(DataSnapshot dataSnapshot) {


                                                                    String location=dataSnapshot.child("Location").getValue().toString();

                                                                    Calendar cal=Calendar.getInstance();

                                                                    SimpleDateFormat format=new SimpleDateFormat("HH:mm:ss");

                                                                    String time=format.format(cal.getTime());
                                                                    final String date= DateFormat.getDateInstance(DateFormat.SHORT).format(cal.getTime());




                                                                    Map ellah=new HashMap();

                                                                    String user_recieve=getIntent().getStringExtra("advanced_request_recieve_user");

                                                                    ellah.put("Image",image);
                                                                    ellah.put("first_desc",desc);
                                                                    ellah.put("Image2",ibraas);
                                                                    ellah.put("Desc2", desc1);
                                                                    ellah.put("UID", user_string);
                                                                    ellah.put("Location",location);
                                                                    ellah.put("Date", date);
                                                                    ellah.put("post1", postvalue);
                                                                    ellah.put("post2",postvalue2);
                                                                    ellah.put("second_user",user_recieve);


                                                                   // String user_recieve=getIntent().getStringExtra("advanced_request_recieve_user");



                                                                    DatabaseReference databaseReference2=FirebaseDatabase.getInstance()
                                                                            .getReference("advanced_trade_requests").child(user_recieve).push();


                                                                    databaseReference2.setValue(ellah).addOnCompleteListener(new OnCompleteListener<Void>() {
                                                                        @Override
                                                                        public void onComplete(@NonNull Task<Void> task) {

                                                                            if (task.isSuccessful())
                                                                            {


                                                                                progressDialog.dismiss();

                                                                                Toast.makeText(ItemSelector.this, "Request Succesfully Made", Toast.LENGTH_SHORT).show();


                                                                                Intent
                                                                                        intent=new Intent(ItemSelector.this, AdvancedBarterTrading.class);
                                                                                startActivity(intent);
                                                                            }

                                                                        }
                                                                    });



                                                                }

                                                                @Override
                                                                public void onCancelled(DatabaseError databaseError) {

                                                                }
                                                            });










                                                        }

                                                        @Override
                                                        public void onCancelled(DatabaseError databaseError) {

                                                        }
                                                    });





                                                }

                                                @Override
                                                public void onCancelled(DatabaseError databaseError) {

                                                }
                                            }
                                    );
                                }





                            }
                        });

                        builder.show();




                      /*  String user_value = clickItem.getPost_id();
                        String uid=clickItem.getUID();

                        Intent intent = new Intent(ItemSelector.this, Advanced_details.class);
                        intent.putExtra("UID", user_value);
                        intent.putExtra("user_id",uid);
                        Toast.makeText(ItemSelector.this, ""+user_value, Toast.LENGTH_SHORT).show();





                        startActivity(intent);
                        */












                    }
                });

            }


        };

        recyclerView.setAdapter(adapter);




    }
}
