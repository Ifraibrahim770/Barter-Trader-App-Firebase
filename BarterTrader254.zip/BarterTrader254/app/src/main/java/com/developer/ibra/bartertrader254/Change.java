package com.developer.ibra.bartertrader254;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Change extends AppCompatActivity {

    private Toolbar account;
    private Button change_status;
    private TextInputLayout status;

    private FirebaseAuth firebaseAuth;
    private DatabaseReference databaseReference;

    private ProgressDialog progressDialog;

    private Button namechanger;

    private TextInputLayout usernamechanger;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change);


        account=(Toolbar)findViewById(R.id.profile_name);
        change_status=(Button)findViewById(R.id.change_button_status);
        status=(TextInputLayout)findViewById(R.id.change_status);
        namechanger=(Button)findViewById(R.id.name_button);
        usernamechanger=(TextInputLayout)findViewById(R.id.change_username);




        String string34=getIntent().getStringExtra("status_value");

        String name=getIntent().getStringExtra("name_value");

        status.getEditText().setText(string34);
        usernamechanger.getEditText().setText(name);

        progressDialog=new ProgressDialog(this);

        setSupportActionBar(account);
        getSupportActionBar().setTitle("Update Status");

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        firebaseAuth=FirebaseAuth.getInstance();
        FirebaseUser firebaseUser=firebaseAuth.getCurrentUser();

        progressDialog.setTitle("Updating Status...");
        progressDialog.setMessage("Please Wait...");

        progressDialog.setCancelable(false);


        if (firebaseUser!=null)
        {

            String uid=firebaseUser.getUid();
            databaseReference= FirebaseDatabase.getInstance().getReference().child("Users").child(uid);





            change_status.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {


                    String new_status=status.getEditText().getText().toString();


                    if (!TextUtils.isEmpty(new_status)) {

                        progressDialog.show();


                        databaseReference.child("Status").setValue(new_status);


                        databaseReference.child("Status").setValue(new_status).addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {


                                if (task.isSuccessful())


                                {
                                    progressDialog.dismiss();
                                    Toast.makeText(Change.this, "Status, Succesfully Updated", Toast.LENGTH_LONG).show();

                                    Intent intent=new Intent(Change.this, Account.class);
                                    startActivity(intent);
                                } else

                                {
                                    progressDialog.dismiss();
                                    Toast.makeText(Change.this, "Error: " + task.getException().getMessage(), Toast.LENGTH_LONG).show();
                                }

                            }
                        });

                    }

                    else
                    {
                        Toast.makeText(Change.this, "You cant update an empty status", Toast.LENGTH_LONG).show();
                    }
                }
            });



            namechanger.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {


                    String newname=usernamechanger.getEditText().getText().toString();


                    if (!TextUtils.isEmpty(newname))

                    {

                        progressDialog.show();

                        databaseReference.child("Name").setValue(newname).addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {


                                if (task.isSuccessful())
                                {



                                    progressDialog.dismiss();

                                    Toast.makeText(Change.this, "You have succesfully changed your name", Toast.LENGTH_LONG).show();
                                }



                            }
                        });

                    }


                    else

                    {
                        Toast.makeText(Change.this, "Please Provide a valid username", Toast.LENGTH_LONG).show();
                    }

                }
            });
        }







    }

}
