package com.developer.ibra.bartertrader254;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Toast;

import com.developer.ibra.bartertrader254.Interface.ItemClickListener;
import com.developer.ibra.bartertrader254.ViewHolder.MenuViewHolder;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.squareup.picasso.Picasso;

public class AllUsers extends AppCompatActivity {


    private DatabaseReference mDatabase;
    private ProgressDialog progressDialog;
    private RecyclerView user_menu;
    private Query ibra;

    private RecyclerView.LayoutManager layoutManager;

    private Toolbar user_toolbar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_all_users);


        mDatabase= FirebaseDatabase.getInstance().getReference().child("Users");
        mDatabase.keepSynced(true);
        ibra=mDatabase.orderByChild("Name");

        user_menu=(RecyclerView)findViewById(R.id.recycler_menu78);
        user_toolbar=(Toolbar)findViewById(R.id.user_bar);
        user_menu.setHasFixedSize(true);

        layoutManager=new LinearLayoutManager(this);
        user_menu.setLayoutManager(layoutManager);

        setSupportActionBar(user_toolbar);
        getSupportActionBar().setTitle("All Barter Traders");

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        progressDialog=new ProgressDialog(this);




        loadmenu();

    }

    private void loadmenu() {

        FirebaseRecyclerAdapter <Category, MenuViewHolder> adapter=new FirebaseRecyclerAdapter<Category, MenuViewHolder>(Category.class, R.layout.user_item, MenuViewHolder.class,ibra) {
            @Override
            protected void populateViewHolder(MenuViewHolder viewHolder, final Category model, int position) {

                viewHolder.displayname.setText(model.getName());
                viewHolder.uid.setText(model.getUID());
                viewHolder.status.setText(model.getStatus());


                    Picasso.with(AllUsers.this).load(model.getThumb_image()).placeholder(R.drawable.default_circle).into(viewHolder.profile_pic);




                final Category clickItem=model;
                viewHolder.setItemClickListener(new ItemClickListener() {
                    @Override
                    public void onClick(View view, int position, boolean isLongClick) {






                        CharSequence options[]=new CharSequence[]{ "Message Seller", "Report User", "View Profile"};

                        final AlertDialog.Builder builder=new AlertDialog.Builder(AllUsers.this);

                        builder.setTitle("Select Option");
                        builder.setItems(options, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i)


                            {




                                if (i==0)

                                {

                                    Intent intent=new Intent(AllUsers.this, Chat.class);

                                    String string=model .getUID();

                                    intent.putExtra("Message_uid", string);


                                    startActivity(intent);


                                }


                                if (i==1)

                                {

                                }



                                if (i==2)


                                {

                                    String  user_value=model.getUID();
                                    Intent intent=new Intent(AllUsers.this, Profile.class);
                                    intent.putExtra("UID",user_value);


                                    startActivity(intent);


                                }

                            }
                        });

                        builder.show();





                    }
                });

            }
        };


        user_menu.setAdapter(adapter);



    }


}
