package com.developer.ibra.bartertrader254;

import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

class SectionsPageAdapter  extends FragmentPagerAdapter{
    public SectionsPageAdapter(FragmentManager fm) {
        super(fm);
    }

    @Override
    public Fragment getItem(int position) {

        switch (position)
        {
            case 0:
                my_posts_frag my_posts_frag=new my_posts_frag();
                return my_posts_frag;

            case 1:
                posts_frag posts_frag=new posts_frag();
                return posts_frag;


            case 2:
                BlankFragment blankFragment=new BlankFragment();
                return blankFragment;

              default:

                  return null;



        }

    }

    @Override
    public int getCount() {
        return 3;
    }

    @Nullable
    @Override
    public CharSequence getPageTitle(int position) {

        switch (position)
        {
            case 0:
                return "TRADE POSTS";


            case 1:
                return "MY POSTS";


            case 2:
                return "MESSAGES";

            default:
                return null;





        }

    }
}
