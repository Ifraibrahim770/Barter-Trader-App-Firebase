package com.developer.ibra.bartertrader254;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.theartofdev.edmodo.cropper.CropImage;
import com.theartofdev.edmodo.cropper.CropImageView;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

import id.zelory.compressor.Compressor;

public class Advanced_post extends AppCompatActivity {


    private TextInputLayout second_desc;
    private android.support.v7.widget.Toolbar toolbar;

    private ImageView imageView;
    private Uri first_image=null;

    private StorageReference mStorage;
    private DatabaseReference databaseReference;


    private Button finish;

    private ProgressDialog progressDialog;


    private Bitmap compressedImageFile;
    private String downloadstring;



    private String location;
    private String user_thumb;
    private String name;


    private FirebaseUser firebaseUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_advanced_post);


        finish=(Button)findViewById(R.id.advanced_button);


        toolbar=(android.support.v7.widget.Toolbar)findViewById(R.id.advanced_post_postbar);

        imageView=(ImageView)findViewById(R.id.advanced_image);


        second_desc=(TextInputLayout)findViewById(R.id.advanced_hint);

        progressDialog=new ProgressDialog(this);

        progressDialog.setMessage("Finalizing...");

        firebaseUser= FirebaseAuth.getInstance().getCurrentUser();


       // String dbref=getIntent().getStringExtra("data");



        mStorage=FirebaseStorage.getInstance().getReference();
        databaseReference= FirebaseDatabase.getInstance().getReference("Advanced_posts").push();




        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Add Goods to Wallet");

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);



        String hint=("Product Description...");

        second_desc.setHint(hint);


        finish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                final DatabaseReference snapshot=FirebaseDatabase.getInstance().getReference("Users").child(firebaseUser.getUid());


                snapshot.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {


                        location=dataSnapshot.child("Location").getValue().toString();
                        user_thumb=dataSnapshot.child("Thumb_image").getValue().toString();
                        name=dataSnapshot.child("Name").getValue().toString();

                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {

                    }
                });



                final String seconddesc=second_desc.getEditText().getText().toString();


                final String randoma= UUID.randomUUID().toString();


                if(first_image!=null && !TextUtils.isEmpty(seconddesc))

                {
                    progressDialog.show();

                    StorageReference filepath=mStorage.child("Post_Images").child(randoma+".jpg");
                    filepath.putFile(first_image).addOnCompleteListener(new OnCompleteListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<UploadTask.TaskSnapshot> task) {


                            if (task.isSuccessful())

                            {

                                String imagepath=task.getResult().getDownloadUrl().toString();

                                File actualImageFile=new File(first_image.getPath());


                                compressedImageFile = new Compressor(Advanced_post.this).compressToBitmap(actualImageFile);
                                ByteArrayOutputStream byteArrayOutputStream=new ByteArrayOutputStream();


                                compressedImageFile.compress(Bitmap.CompressFormat.JPEG,75,byteArrayOutputStream);
                                final byte  [] data=byteArrayOutputStream.toByteArray();


                                UploadTask uploadTask=mStorage.child("Post_Images/thumbs")
                                        .child(randoma+".jpg").putBytes(data);


                                uploadTask.addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                                    @Override
                                    public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {

                                        Calendar cal=Calendar.getInstance();

                                        SimpleDateFormat format=new SimpleDateFormat("HH:mm:ss");

                                        String time=format.format(cal.getTime());
                                        final String date= DateFormat.getDateInstance(DateFormat.SHORT).format(cal.getTime());




                                        final String downloadstring2=taskSnapshot.getDownloadUrl().toString();

                                        Map ibra=new HashMap();

                                        ibra.put("Image2", downloadstring2);
                                        ibra.put("Desc2", seconddesc);
                                        //ibra.put("Name", name);
                                        ibra.put("Location", location);
                                        ibra.put("UID", firebaseUser.getUid());
                                        ibra.put("Post_id", databaseReference.getKey());
                                        ibra.put("Date", date);

                                        databaseReference.setValue(ibra);




                                        progressDialog.dismiss();


                                        Intent intent=new Intent(Advanced_post.this, MainActivity.class);

                                        startActivity(intent);

                                        Toast.makeText(Advanced_post.this, "Success!, Your Post is being reviewed", Toast.LENGTH_LONG).show();




                                    }
                                }).addOnFailureListener(new OnFailureListener() {
                                    @Override
                                    public void onFailure(@NonNull Exception e) {

                                    }
                                });




                            }


                            else
                            {

                                progressDialog.dismiss();

                                Toast.makeText(Advanced_post.this, "Error: "+task.getException().getMessage(),Toast.LENGTH_LONG).show();
                            }

                        }
                    });

                }


                else

                {
                    Toast.makeText(Advanced_post.this, "Please fill in all empty fields", Toast.LENGTH_LONG).show();
                }



            }
        });


        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                CropImage.activity()
                        .setGuidelines(CropImageView.Guidelines.ON)
                        .setMinCropResultSize(512, 512)
                        .setAspectRatio(16, 11)
                        .start(Advanced_post.this);
            }
        });
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);


        if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE) {
            CropImage.ActivityResult result = CropImage.getActivityResult(data);
            if (resultCode == RESULT_OK) {

                first_image = result.getUri();
                imageView.setImageURI(first_image);

            } else if (resultCode == CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE) {

                Exception error = result.getError();

            }
        }




    }


    public static String random() {
        Random generator = new Random();
        StringBuilder randomStringBuilder = new StringBuilder();
        int randomLength = generator.nextInt(10);
        char tempChar;
        for (int i = 0; i < randomLength; i++){
            tempChar = (char) (generator.nextInt(96) + 32);
            randomStringBuilder.append(tempChar);
        }
        return randomStringBuilder.toString();
    }



}
