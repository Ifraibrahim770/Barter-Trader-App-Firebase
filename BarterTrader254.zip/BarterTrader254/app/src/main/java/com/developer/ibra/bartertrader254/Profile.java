package com.developer.ibra.bartertrader254;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

import com.developer.ibra.bartertrader254.Interface.ItemClickListener;
import com.developer.ibra.bartertrader254.ViewHolder.Post_ViewHolder;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Callback;
import com.squareup.picasso.NetworkPolicy;
import com.squareup.picasso.Picasso;

import de.hdodenhof.circleimageview.CircleImageView;

public class Profile extends AppCompatActivity {


    private TextView Name;
    private TextView Status;
    private TextView Date;
    private CircleImageView dp;
    private ProgressDialog progressDialog;


    private FirebaseAuth mAuth;
    private DatabaseReference databaseReference;



    private DatabaseReference mDatabase;



    private LinearLayoutManager layoutManager;

    private Picasso mPicasso;

    private RecyclerView recyclerView;


    private TextView posts_number;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);


        mAuth=FirebaseAuth.getInstance();

        FirebaseUser firebaseUser=mAuth.getCurrentUser();

        String user_id=getIntent().getStringExtra("UID");

        databaseReference= FirebaseDatabase.getInstance().getReference().child("Users").child(user_id);
        databaseReference.keepSynced(true);
        mDatabase= FirebaseDatabase.getInstance().getReference("User_posts").child(user_id);
        mDatabase.keepSynced(true);

        recyclerView=(RecyclerView)findViewById(R.id.profile_recycler);
        posts_number=(TextView)findViewById(R.id.profile_posts_number);

        mPicasso=Picasso.with(Profile.this);
        mPicasso.setIndicatorsEnabled(false);


        recyclerView.setHasFixedSize(true);

        layoutManager=new LinearLayoutManager(this);
        layoutManager.setReverseLayout(true);
        layoutManager.setStackFromEnd(true);
        recyclerView.setLayoutManager(layoutManager);



        Date=(TextView)findViewById(R.id.profile_date);
        Name=(TextView)findViewById(R.id.profile_name);
        Status=(TextView)findViewById(R.id.profile_status);
        dp=(CircleImageView)findViewById(R.id.profile_image);


        progressDialog=new ProgressDialog(this);
        progressDialog.setMessage("Retrieving User Details...");
        progressDialog.setTitle("Loading");
        progressDialog.setCancelable(false);

        progressDialog.show();


        loadmenu();


        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {


                String date=dataSnapshot.child("Date").getValue().toString();
                String name=dataSnapshot.child("Name").getValue().toString();
                String status=dataSnapshot.child("Status").getValue().toString();
                final String image=dataSnapshot.child("Image").getValue().toString();


                if(!image.equals("default"))

                {

                    Picasso.with(Profile.this).load(image).networkPolicy(NetworkPolicy.OFFLINE)
                            .placeholder(R.drawable.default_circle).into(dp, new Callback() {
                        @Override
                        public void onSuccess() {

                        }

                        @Override
                        public void onError() {

                            Picasso.with(Profile.this).load(image).placeholder(R.drawable.default_circle).into(dp);

                        }
                    });
                }



                Date.setText(date);
                Name.setText(name);
                Status.setText(status);



                progressDialog.dismiss();

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

    }

    private void loadmenu() {


        FirebaseRecyclerAdapter<Constructor, Post_ViewHolder> adapter = new FirebaseRecyclerAdapter<Constructor, Post_ViewHolder>(Constructor.class, R.layout.post_item, Post_ViewHolder.class, mDatabase) {
            @Override
            protected void populateViewHolder(final Post_ViewHolder viewHolder, final Constructor model, int position) {


                if (!model.getThumb_image().equals("null") && !model.getImage().equals("null") && !model.getImage2().equals("null")) {



                    mPicasso.load(model.getImage()).networkPolicy(NetworkPolicy.OFFLINE).placeholder(R.drawable.default_circle).into(viewHolder.first_image, new Callback() {
                        @Override
                        public void onSuccess() {

                        }

                        @Override
                        public void onError() {

                            mPicasso.load(model.getImage()).placeholder(R.drawable.default_circle).into(viewHolder.first_image);

                        }
                    });

                    mPicasso.load(model.getImage2()).networkPolicy(NetworkPolicy.OFFLINE).placeholder(R.drawable.default_circle).into(viewHolder.second_image, new Callback() {
                        @Override
                        public void onSuccess() {


                        }

                        @Override
                        public void onError() {

                            mPicasso.load(model.getImage2()).placeholder(R.drawable.default_circle).into(viewHolder.second_image);

                        }
                    });


                }


                DatabaseReference munyao=FirebaseDatabase.getInstance().getReference("Users").child(model.getUID());

                munyao.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {


                        String username=dataSnapshot.child("Name").getValue().toString();


                        final String thumb=dataSnapshot.child("Thumb_image").getValue().toString();

                        mPicasso.load(thumb).networkPolicy(NetworkPolicy.OFFLINE).placeholder(R.drawable.default_circle).into(viewHolder.user_thumbnail, new Callback() {
                            @Override
                            public void onSuccess() {

                            }

                            @Override
                            public void onError() {

                                mPicasso.load(thumb).placeholder(R.drawable.default_circle).into(viewHolder.user_thumbnail);

                            }
                        });


                        viewHolder.user_name.setText(username);
                        viewHolder.date1.setText(model.getDate());
                        viewHolder.user_location.setText(model.getLocation());

                        viewHolder.first_description.setText(model.getFirst_desc());
                        viewHolder.second_description.setText(model.getDesc2());


                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {

                    }
                });



                String ibrahim=model.getPost_id();


                DatabaseReference databaseReference=FirebaseDatabase.getInstance().getReference("Comments").child(ibrahim);
                databaseReference.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {

                        int arodi= (int) dataSnapshot.getChildrenCount();
                        String pro2=String.valueOf(arodi);


                        viewHolder.comment_count.setText(pro2);


                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {

                    }
                });



                viewHolder.user_name.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {



                        String userid=model.getUID();

                        Intent intent=new Intent(Profile.this, Profile.class);

                        intent.putExtra("UID", userid);
                        startActivity(intent);
                    }
                });

                viewHolder.user_thumbnail.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        String userid=model.getUID();

                        Intent intent=new Intent(Profile.this, Profile.class);

                        intent.putExtra("UID", userid);
                        startActivity(intent);

                    }
                });

                viewHolder.message.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                        Intent intent=new Intent(Profile.this, Chat.class);
                        startActivity(intent);

                    }
                });


                viewHolder.mesage.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                        Intent intent=new Intent(Profile.this, Chat.class);
                        startActivity(intent);

                    }
                });






                final Constructor clickItem = model;
                viewHolder.setItemClickListener(new ItemClickListener() {
                    @Override
                    public void onClick(View view, int position, boolean isLongClick) {


                        String user_value = clickItem.getPost_id();
                        Intent intent = new Intent(Profile.this, Comments.class);
                        intent.putExtra("UID", user_value);


                        startActivity(intent);


                    }
                });

            }


        };

        recyclerView.setAdapter(adapter);


        mDatabase.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {


                int ibra= (int) dataSnapshot.getChildrenCount();

                String pro2=String.valueOf(ibra);

                posts_number.setText(pro2);

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

    }





}
