package com.developer.ibra.bartertrader254;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.support.v7.widget.Toolbar;
import android.view.View;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class PostActivity extends AppCompatActivity {


    private Toolbar mToolbar;

    private CardView goods_goods;
    private CardView gs;
    private CardView sg;
    private CardView ss;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post);

        mToolbar=(Toolbar)findViewById(R.id.post_bar);
        goods_goods=(CardView)findViewById(R.id.post_goods_goods);
        gs=(CardView)findViewById(R.id.post_good_services);
        sg=(CardView)findViewById(R.id.post_services_goods);
        ss=(CardView)findViewById(R.id.post_serv_serv);

        setSupportActionBar(mToolbar);
        getSupportActionBar().setTitle("Add a New Post");

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);





        goods_goods.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(PostActivity.this, PostData.class);

                intent.putExtra("description", "Goods For Goods");

                intent.putExtra("hint1","Description of Goods");
                intent.putExtra("hint2", "Description of Goods");
                startActivity(intent);
            }
        });

        gs.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(PostActivity.this, PostData.class);
                intent.putExtra("description", "Goods For Services");

                intent.putExtra("hint1", "Description of Goods");
                intent.putExtra("hint2", "Description of Services");
                startActivity(intent);
            }
        });

        sg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(PostActivity.this, PostData.class);
                intent.putExtra("description", "Services For Goods");
                intent.putExtra("hint1", "Description of Services");
                intent.putExtra("hint2", "Description of Goods");
                startActivity(intent);
            }
        });

        ss.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(PostActivity.this, PostData.class);
                intent.putExtra("description", "Services For Services");

                intent.putExtra("hint1", "Description of Services");
                intent.putExtra("hint2", "Description of Services");

                startActivity(intent);
            }
        });
    }



}
