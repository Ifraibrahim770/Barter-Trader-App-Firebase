package com.developer.ibra.bartertrader254;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.developer.ibra.bartertrader254.Interface.ItemClickListener;
import com.developer.ibra.bartertrader254.ViewHolder.Comment_ViewHolder;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import de.hdodenhof.circleimageview.CircleImageView;

public class Comments extends AppCompatActivity {

    private TextView name;
    private TextView location;
    private TextView date;
    private CircleImageView thumb;
    private ImageView first_image;
    private ImageView second_image;
    private TextView first_desc;
    private TextView second_desc;
    private TextInputLayout comment;
    private ImageView xender;

    private DatabaseReference databaseReference;

    private String post_id;

    private ProgressDialog progressDialog;

    private DatabaseReference user;

    private ProgressDialog mProgress;


    private RecyclerView mview2;
    private DatabaseReference comment_ref;
    private LinearLayoutManager layoutManager;





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_comments);

        post_id=getIntent().getStringExtra("UID");


        databaseReference= FirebaseDatabase.getInstance().getReference("Approved Posts").child(post_id);
        databaseReference.keepSynced(true);

        name=(TextView)findViewById(R.id.comment_name);
        location=(TextView)findViewById(R.id.comment_location);
        date=(TextView)findViewById(R.id.comment_date);
        thumb=(CircleImageView)findViewById(R.id.comment_thumb);
        first_image=(ImageView)findViewById(R.id.comment_image1);
        second_image=(ImageView)findViewById(R.id.comment_image2);
        first_desc=(TextView) findViewById(R.id.mbuya_description);
        second_desc=(TextView)findViewById(R.id.comment_desc2);

        mview2=(RecyclerView)findViewById(R.id.recycler_comment);

        comment=(TextInputLayout)findViewById(R.id.comment_edit_text);

        xender=(ImageView)findViewById(R.id.comment_send);

        progressDialog=new ProgressDialog(this);
        mProgress=new ProgressDialog(this);


        mProgress.setMessage("Adding Comment");
        mProgress.setCanceledOnTouchOutside(false);


        progressDialog.setMessage("Loading Post Details...");


        progressDialog.show();


        layoutManager = new LinearLayoutManager(this);
        //layoutManager.setReverseLayout(true);
        //layoutManager.setStackFromEnd(true);
        mview2.setLayoutManager(layoutManager);

        comment_ref=FirebaseDatabase.getInstance().getReference("Comments").child(post_id);
        comment_ref.keepSynced(true);




        loadcomments();



        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {



                if(!TextUtils.isEmpty(dataSnapshot.child("Name").getValue().toString()))

                {


                    final String name2 = dataSnapshot.child("Name").getValue().toString();
                    final String date2 = dataSnapshot.child("Date").getValue().toString();
                    final String location2 = dataSnapshot.child("Location").getValue().toString();
                    // String post_id=dataSnapshot.child("Post_id").getValue().toString();
                    final String thumb_image2 = dataSnapshot.child("Thumb_image").getValue().toString();
                    final String desc12 = dataSnapshot.child("first_desc").getValue().toString();
                    String uid2 = dataSnapshot.child("UID").getValue().toString();
                    ;
                    final String desc22 = dataSnapshot.child("Desc2").getValue().toString();
                    final String image12 = dataSnapshot.child("Image").getValue().toString();
                    final String image22 = dataSnapshot.child("Image2").getValue().toString();


                    DatabaseReference uandi=FirebaseDatabase.getInstance().getReference("Users").child(uid2);

                    uandi.addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(DataSnapshot dataSnapshot) {


                            String soombili=dataSnapshot.child("Name").getValue().toString();
                            String thh=dataSnapshot.child("Thumb_image").getValue().toString();



                            name.setText(soombili);
                            location.setText(location2);
                            date.setText(date2);

                            Picasso.with(Comments.this).load(thh).placeholder(R.drawable.default_circle).into(thumb);
                            Picasso.with(Comments.this).load(image12).placeholder(R.drawable.default_circle).into(first_image);
                            Picasso.with(Comments.this).load(image22).placeholder(R.drawable.default_circle).into(second_image);


                            first_desc.setText(desc12);
                            second_desc.setText(desc22);


                            progressDialog.dismiss();



                        }

                        @Override
                        public void onCancelled(DatabaseError databaseError) {

                        }
                    });


                }

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });


        xender.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final String comment_val = comment.getEditText().getText().toString();


                if (!TextUtils.isEmpty(comment_val)) {

                    mProgress.show();


                    final DatabaseReference mref2 = FirebaseDatabase.getInstance().getReference("Comments").child(post_id).push();

                    final FirebaseUser firebaseUser = FirebaseAuth.getInstance().getCurrentUser();

                    user = FirebaseDatabase.getInstance().getReference("Users").child(firebaseUser.getUid());

                    user.addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(DataSnapshot dataSnapshot) {


                            String name = dataSnapshot.child("Name").getValue().toString();

                            String image = dataSnapshot.child("Image").getValue().toString();


                            Calendar cal = Calendar.getInstance();

                            SimpleDateFormat format = new SimpleDateFormat("HH:mm");

                            String time = format.format(cal.getTime());
                            String date = DateFormat.getDateInstance(DateFormat.SHORT).format(cal.getTime());


                            Map map = new HashMap();
                            map.put("Name", name);
                            map.put("Image", image);
                            map.put("Date", date);
                            map.put("Time", time);
                            map.put("Comment", comment_val);
                            map.put("UID", firebaseUser.getUid());


                            mref2.setValue(map).addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {


                                    if (task.isSuccessful()) {

                                        mProgress.dismiss();

                                        Toast.makeText(Comments.this, "Comment Succesfully Added", Toast.LENGTH_LONG).show();
                                        comment.getEditText().getText().clear();
                                    }

                                }
                            });


                        }

                        @Override
                        public void onCancelled(DatabaseError databaseError) {

                        }
                    });


                }

                else
                {

                    Toast.makeText(Comments.this, "Please  type in a comment first...", Toast.LENGTH_LONG).show();

                }
            }
        });




    }

    private void loadcomments() {


        FirebaseRecyclerAdapter<Comment_Category, Comment_ViewHolder> adapter = new FirebaseRecyclerAdapter<Comment_Category, Comment_ViewHolder>(Comment_Category.class, R.layout.comment_item, Comment_ViewHolder.class, comment_ref) {
            @Override
            protected void populateViewHolder(final Comment_ViewHolder viewHolder, final Comment_Category model, int position) {




                DatabaseReference kamore=FirebaseDatabase.getInstance().getReference("Users").child(model.getUID());


                kamore.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {



                        String michael=dataSnapshot.child("Name").getValue().toString();

                        String kyalo=dataSnapshot.child("Thumb_image").getValue().toString();



                        if(!model.getImage().equals("null"))
                        {

                            Picasso.with(Comments.this).load(kyalo).placeholder(R.drawable.default_circle).into(viewHolder.lily_thumb);


                        }


                        viewHolder.lily_name.setText(michael);
                        viewHolder.lily_date.setText(model.getDate());
                        viewHolder.lily_time.setText(model.getTime());
                        viewHolder.lily_comment.setText(model.getComment());



                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {

                    }
                });








                final Comment_Category clickItem = model;
                viewHolder.setItemClickListener(new ItemClickListener() {
                    @Override
                    public void onClick(View view, int position, boolean isLongClick) {


                        String user_value = clickItem.getUID();
                        Intent intent = new Intent(Comments.this, Profile.class);
                        intent.putExtra("UID", user_value);
                        startActivity(intent);





                    }
                });

            }










        };

        mview2.setAdapter(adapter);

    }



}
