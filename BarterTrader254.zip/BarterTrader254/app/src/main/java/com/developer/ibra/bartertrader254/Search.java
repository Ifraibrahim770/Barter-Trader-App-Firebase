package com.developer.ibra.bartertrader254;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Toast;

import com.algolia.instantsearch.core.helpers.Searcher;
import com.algolia.instantsearch.ui.helpers.InstantSearch;
import com.algolia.instantsearch.ui.utils.ItemClickSupport;
import com.algolia.instantsearch.ui.views.Hits;
import com.algolia.instantsearch.ui.views.SearchBox;

import net.minidev.json.JSONObject;

import org.json.JSONException;

public class Search extends AppCompatActivity {

    Searcher searcher;
    InstantSearch helper;
    Hits hits;


    private SearchBox searchBox;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        searcher = Searcher.create("WF9P8V64FX", "30afe072bc9fef610c71c44aacacb707", "post_items");
        helper = new InstantSearch(Search.this, searcher);
        helper.search();



        String search=getIntent().getStringExtra("image_result");


        searchBox=(SearchBox)findViewById(R.id.search);


        searchBox.setQueryHint(search);

        hits=findViewById(R.id.hits);
        hits.setOnItemClickListener(new ItemClickSupport.OnItemClickListener() {
            @Override
            public void onItemClick(RecyclerView recyclerView, int position, View v) {
                org.json.JSONObject hit = hits.get(position);
                String object_id = null;
                try {
                    object_id = hit.getString("objectID");
                } catch (JSONException e) {
                    e.printStackTrace();
                }
             //   Toast.makeText(Search.this, "" + object_id, Toast.LENGTH_SHORT).show();


                Intent intent=new Intent(Search.this, Comments.class);
                intent.putExtra("UID", object_id);
                startActivity(intent);
               // startActivity(new Intent(Search.this, Comments.class).putExtra(object_id, "UID"));
            }
        });
    }

    @Override
    protected void onDestroy() {
        searcher.destroy();
        super.onDestroy();
    }

}
