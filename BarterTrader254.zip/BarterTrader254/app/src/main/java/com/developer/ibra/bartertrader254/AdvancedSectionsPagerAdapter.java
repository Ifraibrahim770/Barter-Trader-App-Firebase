package com.developer.ibra.bartertrader254;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

class AdvancedSectionsPagerAdapter extends FragmentPagerAdapter {
    public AdvancedSectionsPagerAdapter(FragmentManager fm) {
        super(fm);
    }

    @Override
    public Fragment getItem(int position) {


        switch (position)
        {
            case 0:
                tradeitems tradeitem=new tradeitems();
                return tradeitem;


            case 1:
                requests_frag requests_frag=new requests_frag();
                return requests_frag;


            case 2:
                wallet_frag wallet_frag=new wallet_frag();
                return wallet_frag;

                default:
                    return null;


        }

    }

    @Override
    public int getCount() {
        return 3;
    }


    public CharSequence getPageTitle(int position) {

        switch (position)
        {
            case 0:
                return "TRADE ITEMS";


            case 1:
                return "REQUESTS";


            case 2:
                return "WALLET";

            default:
                return null;





        }

    }
}
