package com.developer.ibra.bartertrader254;

public class Constructor {



    private String Date;
    private String Desc2;
    private String Image;
    private String Image2;
    private String Location;
    private String Name;
    private String Thumb_image;
    private String UID;
    private String first_desc;
    private String Post_id;
    private String post1;
    private String post2;
    private String second_user;


    public Constructor(String second_user) {
        this.second_user = second_user;
    }


    public String getSecond_user() {
        return second_user;
    }

    public void setSecond_user(String second_user) {
        this.second_user = second_user;
    }

    public Constructor(String post1, String post2) {
        this.post1 = post1;
        this.post2 = post2;
    }

    public String getPost1() {
        return post1;
    }

    public void setPost1(String post1) {
        this.post1 = post1;
    }

    public String getPost2() {
        return post2;
    }

    public void setPost2(String post2) {
        this.post2 = post2;
    }

    public Constructor() {
    }



    public Constructor(String date, String desc2, String image, String image2, String location, String name, String thumb_image, String UID, String first_desc, String post_id) {
        Date = date;
        Desc2 = desc2;
        Image = image;
        Image2 = image2;
        Location = location;
        Name = name;
        Thumb_image = thumb_image;
        this.UID = UID;
        this.first_desc = first_desc;
        Post_id = post_id;
    }

    public String getDate() {
        return Date;
    }

    public void setDate(String date) {
        Date = date;
    }

    public String getDesc2() {
        return Desc2;
    }

    public void setDesc2(String desc2) {
        Desc2 = desc2;
    }

    public String getImage() {
        return Image;
    }

    public void setImage(String image) {
        Image = image;
    }

    public String getImage2() {
        return Image2;
    }

    public void setImage2(String image2) {
        Image2 = image2;
    }

    public String getLocation() {
        return Location;
    }

    public void setLocation(String location) {
        Location = location;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getThumb_image() {
        return Thumb_image;
    }

    public void setThumb_image(String thumb_image) {
        Thumb_image = thumb_image;
    }

    public String getUID() {
        return UID;
    }

    public void setUID(String UID) {
        this.UID = UID;
    }

    public String getFirst_desc() {
        return first_desc;
    }

    public void setFirst_desc(String first_desc) {
        this.first_desc = first_desc;
    }

    public String getPost_id() {
        return Post_id;
    }

    public void setPost_id(String post_id) {
        Post_id = post_id;
    }


}
