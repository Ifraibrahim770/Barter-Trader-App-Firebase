package com.developer.ibra.bartertrader254.Interface;

import android.view.View;

public interface ItemClickListener {

    void onClick (View view, int position, boolean isLongClick);
}
