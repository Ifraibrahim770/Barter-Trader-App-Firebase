package com.developer.ibra.bartertrader254.ViewHolder;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.developer.ibra.bartertrader254.Interface.ItemClickListener;
import com.developer.ibra.bartertrader254.R;

import de.hdodenhof.circleimageview.CircleImageView;

public class Post_ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{




    public CircleImageView user_thumbnail;
    public TextView user_name;
    public TextView user_location;
    public TextView date1;
    public ImageView first_image;
    public ImageView second_image;
    public TextView first_description;
    public TextView second_description;
    public TextView comment_count;




    public CircleImageView user_thumbnail2;
    public TextView user_name2;
    public TextView user_location2;
    public TextView date12;
    public ImageView first_image2;
    public ImageView second_image2;
    public TextView first_description2;
    public TextView second_description2;
    public TextView comment_count2;



    public ImageView message;
    public TextView mesage;



    public TextView loviname;
    public TextView lovidate;
    public  TextView lovilocation;
    public TextView lovidescription;
    public ImageView loviimageview;
    public CircleImageView lovithumb;




    private ItemClickListener itemClickListener;

    public Post_ViewHolder(View itemView) {
        super(itemView);

        user_thumbnail=(CircleImageView)itemView.findViewById(R.id.comment_thumb);
        user_name=(TextView)itemView.findViewById(R.id.view_name);
        user_location=(TextView)itemView.findViewById(R.id.view_location);
        date1=(TextView)itemView.findViewById(R.id.comment_date);
        first_image=(ImageView)itemView.findViewById(R.id.comment_image1);
        second_image=(ImageView)itemView.findViewById(R.id.comment_image2);
        first_description=(TextView)itemView.findViewById(R.id.mbuya_description);
        second_description=(TextView)itemView.findViewById(R.id.comment_desc2);


        comment_count=(TextView)itemView.findViewById(R.id.view_comment_count);
        message=(ImageView)itemView.findViewById(R.id.view_message);

        mesage=(TextView)itemView.findViewById(R.id.text_message);



        loviname=(TextView)itemView.findViewById(R.id.ibra_name);
        lovidate=(TextView)itemView.findViewById(R.id.ibra_date);
        lovilocation=(TextView)itemView.findViewById(R.id.ibra_location);
        lovidescription=(TextView)itemView.findViewById(R.id.ibra_description);
        loviimageview=(ImageView) itemView.findViewById(R.id.ibra_photos);


        lovithumb=(CircleImageView)itemView.findViewById(R.id.ibra_thumb);




        user_thumbnail2=(CircleImageView)itemView.findViewById(R.id.comment_thumb2);
        user_name2=(TextView)itemView.findViewById(R.id.view_name2);
        user_location2=(TextView)itemView.findViewById(R.id.view_location2);
        date12=(TextView)itemView.findViewById(R.id.comment_date2);
        first_image2=(ImageView)itemView.findViewById(R.id.comment_image12);
        second_image2=(ImageView)itemView.findViewById(R.id.comment_image22);
        first_description2=(TextView)itemView.findViewById(R.id.comment_description12);
        second_description2=(TextView)itemView.findViewById(R.id.comment_desc22);












        itemView.setOnClickListener(this);

    }


    public void setItemClickListener(ItemClickListener itemClickListener) {
        this.itemClickListener = itemClickListener;
    }

    @Override
    public void onClick(View view) {


        itemClickListener.onClick(view,getAdapterPosition(),false);

    }
}
