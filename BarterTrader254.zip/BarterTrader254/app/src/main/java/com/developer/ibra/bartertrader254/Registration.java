package com.developer.ibra.bartertrader254;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.widget.Toolbar;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.UserProfileChangeRequest;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

public class  Registration extends AppCompatActivity {
    private FirebaseAuth mAuth;
    private ProgressDialog progressDialog;
    private EditText username;
    private EditText email;
    private EditText password;
    private EditText confirm_password;

    private DatabaseReference mDatabase;

    private Button registration_button;

    private android.support.v7.widget.Toolbar reg_toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);

        mAuth=FirebaseAuth.getInstance();

        username=(EditText)findViewById(R.id.reg_name);
        email=(EditText) findViewById(R.id.reg_email);
        password=(EditText) findViewById(R.id.reg_password);
        confirm_password=(EditText) findViewById(R.id.reg_con_password);

        registration_button=(Button)findViewById(R.id.reg_btn);

        reg_toolbar=(android.support.v7.widget.Toolbar)findViewById(R.id.registration_bar);

        setSupportActionBar(reg_toolbar);

        getSupportActionBar().setTitle("Account Registration Page");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        setSupportActionBar(reg_toolbar);


        progressDialog=new ProgressDialog(this);



        registration_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                final String name=username.getText().toString();
                String user_mail=email.getText().toString();
                String user_password=password.getText().toString();
                String confirm_password_yea=confirm_password.getText().toString();



                if(!TextUtils.isEmpty(name)||!TextUtils.isEmpty(user_mail)||!TextUtils.isEmpty(user_password)||!TextUtils.isEmpty(confirm_password_yea))

                {
                    progressDialog.setTitle("Opening Account...");
                    progressDialog.setMessage("Please wait...");
                    progressDialog.setCancelable(false);
                    if(user_password.equals(confirm_password_yea))

                    {
                        progressDialog.show();


                        mAuth.createUserWithEmailAndPassword(user_mail, user_password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {



                                if(task.isSuccessful())

                                {

                                 /*   createuserprofile();



                                    */


                                 FirebaseUser firebaseUser=FirebaseAuth.getInstance().getCurrentUser();

                                 if(firebaseUser!=null) {


                                     String user_id = firebaseUser.getUid();

                                     mDatabase= FirebaseDatabase.getInstance().getReference().child("Users").child(user_id);
                                     Calendar cal=Calendar.getInstance();

                                     SimpleDateFormat format=new SimpleDateFormat("HH:mm:ss");

                                     String time=format.format(cal.getTime());
                                     String date= DateFormat.getDateInstance(DateFormat.FULL).format(cal.getTime());

                                     Map <String, String> user_details=new HashMap<>();

                                     user_details.put("Name", name);
                                     user_details.put("Status","Hey there! I am a Barter Trader");
                                     user_details.put("Image", "null");
                                     user_details.put("Thumb_image", "default_thumb");
                                     user_details.put("UID",user_id);
                                     user_details.put("Date", date);

                                     mDatabase.setValue(user_details);



                                     progressDialog.dismiss();

                                     Intent mainIntent=new Intent(Registration.this, MainActivity.class);
                                     startActivity(mainIntent);
                                     finish();

                                 }






                                }



                                else
                                {
                                    Toast.makeText(Registration.this, "Error: "+task.getException().getMessage(), Toast.LENGTH_LONG).show();
                                    progressDialog.dismiss();

                                }

                            }
                        });



                    }

                    else

                    {
                        Toast.makeText(Registration.this, "The Passwords  do not match, please check again", Toast.LENGTH_LONG).show();

                    }
                }

                else
                {
                    Toast.makeText(Registration.this, "One or more fields are missing", Toast.LENGTH_LONG).show();
                }

            }
        });



    }

    private void createuserprofile() {


        FirebaseUser firebaseUser=mAuth.getCurrentUser();

        if(firebaseUser!=null)
        {

            UserProfileChangeRequest profileUpdates=new UserProfileChangeRequest.Builder().setDisplayName(username.getText().toString())
                    .build();

            firebaseUser.updateProfile(profileUpdates).addOnCompleteListener(new OnCompleteListener<Void>() {
                @Override
                public void onComplete(@NonNull Task<Void> task) {


                    if (task.isSuccessful())

                    {
                        Toast.makeText(Registration.this, "Username succesfully updated", Toast.LENGTH_LONG).show();
                    }

                    else
                    {Toast.makeText(Registration.this, "Error"+task.getException(),Toast.LENGTH_LONG).show();}

                }
            });;
        }
    }
}
