package com.developer.ibra.bartertrader254;


import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.algolia.instantsearch.ui.views.SearchBox;
import com.developer.ibra.bartertrader254.Interface.ItemClickListener;
import com.developer.ibra.bartertrader254.ViewHolder.Post_ViewHolder;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Callback;
import com.squareup.picasso.NetworkPolicy;
import com.squareup.picasso.Picasso;


/**
 * A simple {@link Fragment} subclass.
 */
public class wallet_frag extends Fragment {

    private RecyclerView recyclerView;
    private DatabaseReference databaseReference;
    private LinearLayoutManager layoutManager;
    private Picasso mPicasso;


    private String name;

    private SearchBox searchBox;


    private FirebaseUser firebaseUser;





    public wallet_frag() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        View view = inflater.inflate(R.layout.fragment_wallet_frag, container, false);


        recyclerView = view.findViewById(R.id.advanced_wallet);

        firebaseUser=FirebaseAuth.getInstance().getCurrentUser();
        databaseReference = FirebaseDatabase.getInstance().getReference("User_approved_advanced_posts").child(firebaseUser.getUid());
        databaseReference.keepSynced(true);

        mPicasso=Picasso.with(getActivity());
        mPicasso.setIndicatorsEnabled(false);

        recyclerView.setHasFixedSize(true);

        layoutManager = new LinearLayoutManager(getActivity());
        layoutManager.setReverseLayout(true);
        layoutManager.setStackFromEnd(true);

        recyclerView.setLayoutManager(layoutManager);
        FirebaseUser firebaseUser= FirebaseAuth.getInstance().getCurrentUser();

        if (firebaseUser!=null)

        {
            loaddata();
        }

        return view;
    }

    private void loaddata() {

        FirebaseRecyclerAdapter<Constructor, Post_ViewHolder> adapter = new FirebaseRecyclerAdapter<Constructor, Post_ViewHolder>(Constructor.class,
                R.layout.advanced_item, Post_ViewHolder.class, databaseReference) {
            @Override
            protected void populateViewHolder(final Post_ViewHolder viewHolder, final Constructor model, int position) {


                DatabaseReference awino=FirebaseDatabase.getInstance().getReference("Users").child(model.getUID());



                awino.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {



                        final String image=dataSnapshot.child("Thumb_image").getValue().toString();

                        mPicasso.load(image).networkPolicy(NetworkPolicy.OFFLINE).placeholder(R.drawable.default_circle).into(viewHolder.lovithumb, new Callback() {
                            @Override
                            public void onSuccess() {

                            }

                            @Override
                            public void onError() {

                                mPicasso.load(image).placeholder(R.drawable.default_circle).into(viewHolder.lovithumb);

                            }
                        });

                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {

                    }
                });






                mPicasso.load(model.getImage2()).networkPolicy(NetworkPolicy.OFFLINE).placeholder(R.drawable.default_circle).into(viewHolder.loviimageview, new Callback() {
                    @Override
                    public void onSuccess() {

                    }

                    @Override
                    public void onError() {

                        mPicasso.load(model.getImage2()).placeholder(R.drawable.default_circle).into(viewHolder.loviimageview);

                    }
                });


                DatabaseReference databaseReference12=FirebaseDatabase.getInstance().getReference("Users").child(model.getUID());


                databaseReference12.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {


                        name=dataSnapshot.child("Name").getValue().toString();


                        viewHolder.loviname.setText(name);
                        viewHolder.lovidate.setText(model.getDate());
                        viewHolder.lovilocation.setText(model.getLocation());

                        //viewHolder.first_description.setText(model.getFirst_desc());
                        viewHolder.lovidescription.setText(model.getDesc2());


                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {

                    }
                });
                String ibrahim=model.getPost_id();








                /*viewHolder.message.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                        Intent intent=new Intent(getActivity(), Chat.class);
                        startActivity(intent);

                    }
                }); */


               /* viewHolder.mesage.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                        Intent intent=new Intent(getActivity(), Chat.class);
                        startActivity(intent);

                    }
                }); */



                viewHolder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
                    @Override
                    public boolean onLongClick(View view) {


                        CharSequence options[]=new CharSequence[]{ "View Post Details", "Report Post", "Message Seller"};

                        final AlertDialog.Builder builder=new AlertDialog.Builder(getActivity());

                        builder.setTitle("Select Option");
                        builder.setItems(options, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i)


                            {





                            }
                        });

                        builder.show();


                        // Toast.makeText(getActivity(), "Umelong Click Msee", Toast.LENGTH_LONG).show();




                        return true;
                    }
                });




                final Constructor clickItem = model;
                viewHolder.setItemClickListener(new ItemClickListener() {
                    @Override
                    public void onClick(View view, int position, boolean isLongClick) {


                        String user_value = clickItem.getPost_id();
                        String uid=clickItem.getUID();

                        Intent intent = new Intent(getActivity(), Advanced_details.class);
                        intent.putExtra("UID", user_value);
                        intent.putExtra("user_id",uid);
                        Toast.makeText(getActivity(), ""+user_value, Toast.LENGTH_SHORT).show();





                        startActivity(intent);












                    }
                });

            }


        };

        recyclerView.setAdapter(adapter);




    }

}
