package com.developer.ibra.bartertrader254;

import android.content.Intent;
import android.media.Image;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Callback;
import com.squareup.picasso.NetworkPolicy;
import com.squareup.picasso.Picasso;

import java.util.jar.Attributes;

import de.hdodenhof.circleimageview.CircleImageView;

public class Advanced_details extends AppCompatActivity {


    private CircleImageView thumb_image;
    private TextView name;
    private TextView location;
    private TextView date;
    private ImageView image2;
    private TextView description;


    private TextView accessories;
    private TextView reciept;
    private TextView condition;
    private TextView functionality;

    private Button reject;

    String userName;
    String postId;

    private Picasso mPicasso;
    private Button approve;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_advanced_details);


        approve=(Button)findViewById(R.id.approve_button);
        reject=(Button)findViewById(R.id.reject_post);



        name=(TextView)findViewById(R.id.detail_name);
        thumb_image=(CircleImageView) findViewById(R.id.detail_thumb);
        location=(TextView)findViewById(R.id.detail_location);
        date=(TextView)findViewById(R.id.detail_date);
        image2=(ImageView)findViewById(R.id.detail_photos);
        description=(TextView)findViewById(R.id.detail_description);



        accessories=(TextView)findViewById(R.id.detail_accessories);
        reciept=(TextView)findViewById(R.id.detail_reciept);
        condition=(TextView)findViewById(R.id.details_repair);
        functionality=(TextView)findViewById(R.id.detail_functionality);

        userName=getIntent().getStringExtra("user_id");
        postId=getIntent().getStringExtra("UID");


        mPicasso=Picasso.with(Advanced_details.this);
        mPicasso.setIndicatorsEnabled(false);


        checkcurrent();


        approve.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent=new Intent(Advanced_details.this, ItemSelector.class);
                intent.putExtra("advanced_post_id",postId );
                intent.putExtra("advanced_request_recieve_user",userName);

                startActivity(intent);
            }
        });



        DatabaseReference user_details= FirebaseDatabase.getInstance().getReference("Users").child(userName);

        user_details.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                String advanced_name=dataSnapshot.child("Name").getValue().toString();
                final String advanced_image=dataSnapshot.child("Thumb_image").getValue().toString();


                name.setText(advanced_name);


                mPicasso.load(advanced_image).networkPolicy(NetworkPolicy.OFFLINE).placeholder(R.drawable.default_circle).into(thumb_image, new Callback() {
                    @Override
                    public void onSuccess() {

                    }

                    @Override
                    public void onError() {

                        mPicasso.load(advanced_image).placeholder(R.drawable.default_circle).into(thumb_image);

                    }
                });


            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });


        DatabaseReference postref=FirebaseDatabase.getInstance().getReference("Approved_advanced_posts").child(postId);
        postref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {


                String acc=dataSnapshot.child("Accessories").getValue().toString();
                String condition_string=dataSnapshot.child("Condition").getValue().toString();
                String date_string=dataSnapshot.child("Date").getValue().toString();
                String desc_string=dataSnapshot.child("Desc2").getValue().toString();
                String func_string=dataSnapshot.child("Functionality").getValue().toString();
                final String image=dataSnapshot.child("Image2").getValue().toString();
                String locationn=dataSnapshot.child("Location").getValue().toString();
                String  reciept_string=dataSnapshot.child("Reciept").getValue().toString();



                mPicasso.load(image).networkPolicy(NetworkPolicy.OFFLINE).placeholder(R.drawable.default_circle).into(image2, new Callback() {
                    @Override
                    public void onSuccess() {

                    }

                    @Override
                    public void onError() {

                        mPicasso.load(image).placeholder(R.drawable.default_circle).into(image2);

                    }
                });


                location.setText(locationn);
                date.setText(date_string);
                description.setText(desc_string);
                accessories.setText(acc);
                reciept.setText(reciept_string);
                condition.setText(condition_string);
                functionality.setText(func_string);



            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }

    private void checkcurrent() {
        FirebaseUser firebaseUser= FirebaseAuth.getInstance().getCurrentUser();

        String uid=firebaseUser.getUid()
                ;

        if (userName.equals(uid))

        {

            approve.setVisibility(View.INVISIBLE);
            reject.setVisibility(View.INVISIBLE);
        }
    }
}
